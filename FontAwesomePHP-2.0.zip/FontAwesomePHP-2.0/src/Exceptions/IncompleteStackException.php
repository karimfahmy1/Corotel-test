<?php

namespace Khill\FontAwesome\Exceptions;

class IncompleteStackException extends \Exception
{
    //
}
