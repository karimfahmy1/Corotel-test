<?php

namespace Khill\FontAwesome\Exceptions;

class CollectionIconException extends \InvalidArgumentException
{
    //
}
