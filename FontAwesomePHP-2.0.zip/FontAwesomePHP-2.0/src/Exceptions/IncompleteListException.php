<?php

namespace Khill\FontAwesome\Exceptions;

class IncompleteListException extends \Exception
{
    //
}
